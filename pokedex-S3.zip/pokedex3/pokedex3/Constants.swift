//
//  Constants.swift
//  pokedex3
//
//  Created by Jonny B on 7/24/16.
//  Copyright © 2016 Jonny B. All rights reserved.
//

import Foundation

let URL_BASE = "http://pokeapi.co"
let URL_POKEMON = "/api/v1/pokemon/"

typealias DownloadComplete = () -> ()
